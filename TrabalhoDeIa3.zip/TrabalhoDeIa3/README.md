# Sumário

Este é um programa que que gera uma árvore de decisão para uma dataset usando o algortimo ID3.

O programa foi desenvolvido usando a linguagem python (versão: Python 3, mais especificamente Python 3.11.1) 

# Execução

### Para executar o programa segue os seguintes passos:

1. Abra o terminal no diretório na qual descomprimiu os ficheiros;
2. Após isso basta executar o ficheiro principal **main.py** usando `python3 main.py`;

3. De seguida aparecerá um campo onde deve inserir o nome do ficheiro(nome.csv) com o conjunto de treinamento. 
	`Enter the name of a file with a dataset (training examples):`

5. Após isso aparece um outro campo `Enter the name of the file with the corresponding test set:`, onde deve inserir o nome do ficheiro com o conjunto de teste;

6. Com isso termina a execução do programa.